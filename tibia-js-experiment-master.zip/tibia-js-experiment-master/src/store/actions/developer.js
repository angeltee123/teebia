export const toggleDebugMode = () => ({
    type: 'TOGGLE_DEBUG_MODE',
});