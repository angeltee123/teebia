export const setMessage = (text) => ({
    type: 'SET_MESSAGE',
    payload: text,
});