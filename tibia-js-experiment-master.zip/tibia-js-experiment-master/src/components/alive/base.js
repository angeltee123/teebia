export default {
    squareSize: 64,
    effects: {},
};