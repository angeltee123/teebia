export default {
    zIndex: 1,
    walkable: false
};