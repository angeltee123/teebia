import styled from 'styled-components';
import Base from '../../../../../styles/tile';
import img from './sprite.png';

export default styled(Base)`
    background-image: url(${img});
`;