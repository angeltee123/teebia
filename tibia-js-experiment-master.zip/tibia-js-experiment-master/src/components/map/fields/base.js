export default {
    effect: {}
};